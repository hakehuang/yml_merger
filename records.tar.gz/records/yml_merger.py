import yaml
import re
import copy
import urllib.request


class YmlMerger(object):

    def __init__(self):
        self.struct = {}

    def _load_file(self, path):
        print('file is: ' + path)
        with open(path) as file:
            content = file.read()
        content = yaml.load(content)
        return content

    def _load_url(self, path, baseaddr):
        url = baseaddr + '/' + path
        print('url is: ' + url)
        request = urllib.request.Request(url)
        response = urllib.request.urlopen(request)
        content = response.read().decode('utf-8')
        content = yaml.load(content)
        return content

    def _merge_structs(self, first, last):
        ''' this is stupid '''
        if isinstance(first, dict) and isinstance(last, dict):
            for key in last:
                # drop __
                if key not in first:
                    first[ key ] = copy.deepcopy(last[ key ])
                elif isinstance(first[ key ], list) and isinstance(last[ key ], list):
                    first[ key ].extend(last[ key ])
                elif isinstance(first[ key ], dict) and isinstance(last[ key ], dict):
                    self._merge_structs(first[ key ], last[ key ])

    def _merge_add(self, add):
        result_struct = {}
        if (isinstance(add, str)):
            print('merge add: ' + add)
            assert add in self.content, add
            if (add not in self.merged):
                self._merge_section(add)
            self._merge_structs(result_struct, self.merged[ add ])
        elif (isinstance(add, dict)):
            assert 'from' in add
            assert 'import' in add
            assert isinstance(add['import'], list)
            tmp_from, tmp_import = add['from'], add['import']
            tmp_baseaddr = add['base'] if 'base' in add else None
            tmp_struct = None
            # process 'from', 'import'
            if (tmp_baseaddr is None and self.baseaddr is None):
                # process local file
                print('merge add from: ' + tmp_from)
                merger = YmlMerger()
                tmp_struct = merger._merge_content(tmp_from, None)
            else:
                # process url
                merger = YmlMerger()
                if (self.baseaddr):
                    print('merge add from: ' + self.baseaddr + '/' + tmp_from)
                    tmp_struct = merger._merge_content(tmp_from, self.baseaddr)
                else:
                    print('merge add from: ' + tmp_baseaddr + '/' + tmp_from)
                    tmp_struct = merger._merge_content(tmp_from, tmp_baseaddr)
            # import 
            if (tmp_struct is not None):
                for key in tmp_import:
                    print('merge add import: ' + key)
                    assert key in tmp_struct
                    self._merge_structs(result_struct, tmp_struct[ key ])
        return result_struct

    def _merge_section(self, name):
        ''' merge section in current struct '''
        print("merge section: " + name)
        assert name in self.content, name
        struct = self.content[ name ]
        if ('__add__' in struct):
            tmp_struct = {}
            for add in struct[ '__add__' ]:
                tmp = self._merge_add(add)
                self._merge_structs(tmp_struct, tmp)
            self._merge_structs(struct, tmp_struct)
            struct.pop('__add__')
        self.merged[ name ] = struct
        return struct

    def _merge_content(self, path, baseaddr=None):
        self.baseaddr = baseaddr
        if (self.baseaddr is None):
            content = self._load_file(path)
        else:
            content = self._load_url(path, baseaddr)
        self.content = content
        self.struct = {}
        self.merged = {}
        for section in self.content:
            if (section not in self.merged):
                self.struct[ section ] = self._merge_section(section)
        return self.struct

    def entry(self, path):
        ''' entry function which launch merge process '''
        content = self._merge_content(path)
        return content





merger = YmlMerger()
content = merger.entry('k64_projects.yml')
print("\n\n\n")
print("final content is content:")
print("\n\n\n")
print(yaml.dump(content))






